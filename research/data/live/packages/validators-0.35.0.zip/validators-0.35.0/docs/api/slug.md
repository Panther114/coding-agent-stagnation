# slug

::: validators.slug.slug
